"""Application configuration."""
