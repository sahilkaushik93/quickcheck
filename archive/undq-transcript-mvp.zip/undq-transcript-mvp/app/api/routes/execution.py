from fastapi import APIRouter, File, UploadFile

from app.api.routes._uploads import validate_csv
from app.core.config import settings
from app.models.responses import ExecutionResult
from app.services.execution import execute_rules


router = APIRouter(prefix=settings.api_prefix, tags=["execution"])


@router.post("/execution", response_model=ExecutionResult)
async def execution(file: UploadFile = File(...)) -> ExecutionResult:
    validate_csv(file)
    return execute_rules(file.filename or "uploaded.csv")
