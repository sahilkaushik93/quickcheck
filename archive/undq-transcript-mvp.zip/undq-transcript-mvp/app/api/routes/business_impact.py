from fastapi import APIRouter, File, UploadFile

from app.api.routes._uploads import validate_csv
from app.core.config import settings
from app.models.responses import BusinessImpactResult
from app.services.business_impact import analyze_business_impact


router = APIRouter(prefix=settings.api_prefix, tags=["business-impact"])


@router.post("/business-impact", response_model=BusinessImpactResult)
async def business_impact(file: UploadFile = File(...)) -> BusinessImpactResult:
    validate_csv(file)
    return analyze_business_impact(file.filename or "uploaded.csv")
