from fastapi import APIRouter, File, UploadFile

from app.api.routes._uploads import validate_csv
from app.core.config import settings
from app.models.responses import EngineResponse
from app.services.engine import run_end_to_end


router = APIRouter(prefix=settings.api_prefix, tags=["engine"])


@router.post("/engine", response_model=EngineResponse)
async def engine(file: UploadFile = File(...)) -> EngineResponse:
    validate_csv(file)
    return run_end_to_end(file.filename or "uploaded.csv")
