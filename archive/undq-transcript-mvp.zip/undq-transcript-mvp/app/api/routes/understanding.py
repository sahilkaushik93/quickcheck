from fastapi import APIRouter, File, UploadFile

from app.api.routes._uploads import validate_csv
from app.core.config import settings
from app.models.responses import ServiceResult
from app.services.understanding import prepare_rules, profile_csv


router = APIRouter(
    prefix=f"{settings.api_prefix}/understanding",
    tags=["understanding"],
)


@router.post("/profiling", response_model=ServiceResult)
async def profiling(file: UploadFile = File(...)) -> ServiceResult:
    validate_csv(file)
    return profile_csv(file.filename or "uploaded.csv")


@router.post("/rules", response_model=ServiceResult)
async def rules(file: UploadFile = File(...)) -> ServiceResult:
    validate_csv(file)
    return prepare_rules(file.filename or "uploaded.csv")
