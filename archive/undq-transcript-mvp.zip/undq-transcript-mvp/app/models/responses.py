from typing import Any

from pydantic import BaseModel, Field


class ServiceResult(BaseModel):
    status: str = "working"
    message: str
    input_file: str
    details: dict[str, Any] = Field(default_factory=dict)


class UnderstandingResult(BaseModel):
    Profile: ServiceResult
    Rules: ServiceResult


class ExecutionResult(BaseModel):
    Observed_Results: ServiceResult


class BusinessImpactResult(BaseModel):
    scores: ServiceResult
    evidences: ServiceResult
    impact_insights: ServiceResult


class EngineResponse(BaseModel):
    understanding: UnderstandingResult
    execution: ExecutionResult
    business_impact: BusinessImpactResult


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
