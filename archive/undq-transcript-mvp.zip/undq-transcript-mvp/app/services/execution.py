from app.models.responses import ExecutionResult, ServiceResult


def execute_rules(filename: str) -> ExecutionResult:
    return ExecutionResult(
        Observed_Results=ServiceResult(
            message="DQ rule execution API is working.",
            input_file=filename,
            details={
                "execution_mode": "synchronous_mvp",
                "result_state": "stub",
            },
        )
    )
