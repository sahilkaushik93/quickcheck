from app.models.responses import BusinessImpactResult, ServiceResult


def analyze_business_impact(filename: str) -> BusinessImpactResult:
    return BusinessImpactResult(
        scores=ServiceResult(
            message="DQ scoring service is working.",
            input_file=filename,
            details={"result_state": "stub"},
        ),
        evidences=ServiceResult(
            message="DQ evidence service is working.",
            input_file=filename,
            details={"mask_sensitive_values": True, "result_state": "stub"},
        ),
        impact_insights=ServiceResult(
            message="Business-impact insight service is working.",
            input_file=filename,
            details={"result_state": "stub"},
        ),
    )
