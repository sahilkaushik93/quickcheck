from app.models.responses import EngineResponse
from app.services.business_impact import analyze_business_impact
from app.services.execution import execute_rules
from app.services.understanding import run_understanding


def run_end_to_end(filename: str) -> EngineResponse:
    """Compose reusable layer services without making HTTP calls internally."""
    return EngineResponse(
        understanding=run_understanding(filename),
        execution=execute_rules(filename),
        business_impact=analyze_business_impact(filename),
    )
