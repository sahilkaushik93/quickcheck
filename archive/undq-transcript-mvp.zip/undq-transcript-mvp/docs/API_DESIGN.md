# API design

Base path: `/api/v1/undq/transcript`

The layer endpoints and end-to-end engine reuse the same service functions. The engine does not make HTTP calls back into the application.

## Engine response

```json
{
  "understanding": {
    "Profile": {},
    "Rules": {}
  },
  "execution": {
    "Observed_Results": {}
  },
  "business_impact": {
    "scores": {},
    "evidences": {},
    "impact_insights": {}
  }
}
```

The current implementation returns stub messages while preserving the target contract.
