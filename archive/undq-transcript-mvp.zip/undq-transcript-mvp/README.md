# UnDQ Transcript DQ MVP

FastAPI scaffold for a transcript metadata data-quality engine.

## API surface

- `GET /health`
- `POST /api/v1/undq/transcript/engine`
- `POST /api/v1/undq/transcript/understanding/profiling`
- `POST /api/v1/undq/transcript/understanding/rules`
- `POST /api/v1/undq/transcript/execution`
- `POST /api/v1/undq/transcript/business-impact`

All POST endpoints currently accept a CSV upload and return contract-shaped stub responses. The engine endpoint composes the same service functions used by the layer-specific endpoints.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open Swagger at `http://127.0.0.1:8000/docs`.

## Test

```bash
pytest -q
```

## Next implementation step

Replace the stub logic in `app/services/` with profiling and DQ rule implementations. Keep the API response contracts unchanged so Streamlit and other consumers do not need to change.
