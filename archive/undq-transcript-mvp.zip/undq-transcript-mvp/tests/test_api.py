from io import BytesIO

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def csv_upload():
    return {"file": ("lumi_sample.csv", BytesIO(b"intrct_id,trnscr_tx\n1,hello"), "text/csv")}


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_engine_contract():
    response = client.post("/api/v1/undq/transcript/engine", files=csv_upload())
    assert response.status_code == 200
    body = response.json()
    assert set(body) == {"understanding", "execution", "business_impact"}
    assert set(body["understanding"]) == {"Profile", "Rules"}
    assert set(body["business_impact"]) == {
        "scores",
        "evidences",
        "impact_insights",
    }


def test_all_layer_endpoints():
    endpoints = [
        "/api/v1/undq/transcript/understanding/profiling",
        "/api/v1/undq/transcript/understanding/rules",
        "/api/v1/undq/transcript/execution",
        "/api/v1/undq/transcript/business-impact",
    ]
    for endpoint in endpoints:
        response = client.post(endpoint, files=csv_upload())
        assert response.status_code == 200


def test_rejects_non_csv():
    response = client.post(
        "/api/v1/undq/transcript/engine",
        files={"file": ("input.txt", BytesIO(b"not a csv"), "text/plain")},
    )
    assert response.status_code == 415
