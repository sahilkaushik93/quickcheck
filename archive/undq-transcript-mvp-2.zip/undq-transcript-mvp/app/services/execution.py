from app.models.responses import ExecutionResult, ServiceResult, UnderstandingResult


def execute_rules(understanding: UnderstandingResult) -> ExecutionResult:
    filename = understanding.Profile.input_file
    return ExecutionResult(
        Observed_Results=ServiceResult(
            message="DQ rule execution API is working.",
            input_file=filename,
            details={
                "execution_mode": "synchronous_mvp",
                "result_state": "stub",
                "rules_received": understanding.Rules.details.get("planned_rules", []),
                "profile_received": True,
            },
        )
    )
